print("Importing modules...")
import os
import zipfile
import requests
print("Initializing functions...")
def download_and_extract_zip(zip_url):
    response = requests.get(zip_url)
    if response.status_code == 200:
        with open('update.zip', 'wb') as f:
            f.write(response.content)
        with zipfile.ZipFile('update.zip', 'r') as zip_ref:
            zip_ref.extractall('.')
        os.remove('update.zip')
def update_files():
    current_dir = os.getcwd()
    zip_url = 'https://alexidians.github.io/Super-Diamond-MC/downloads/Super-Diamond-MC.zip'
    download_and_extract_zip(zip_url)
    #with zipfile.ZipFile('Super-Diamond-MC.zip', 'r') as zip_ref:
    #    for file in zip_ref.namelist():
    #        if file != 'update.py':
    #            file_path = os.path.join(current_dir, file)
    #            print(f"Updating file: {file_path}")
    #            with zip_ref.open(file) as zf, open(file_path, 'wb') as f:
    #                f.write(zf.read())
print("Loaded! Starting Update...")
if __name__ == "__main__":
    try:
     update_files()
    except Exception as e:
     print(e)
    print("Update complete!")
    input("Press enter to exit")
