print("Importing Modules...")
import os
import shutil
import subprocess
import sys
import json
import requests
import zipfile
import hashlib
import urllib.request
import re

try:
    import easygui as eg
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "easygui"])
    import easygui as eg

try:
    import requests
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

try:
    from bs4 import BeautifulSoup
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4"])
    from bs4 import BeautifulSoup

try:
    from datetime import datetime
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "datetime"])
    from datetime import datetime

try:
    import gzip
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "gzip"])
    import gzip

try:
    import pygments
    from pygments import highlight
    from pygments.lexers import get_lexer_by_name
    from pygments.formatters import HtmlFormatter
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pygments"])
    import pygments
    from pygments import highlight
    from pygments.lexers import get_lexer_by_name
    from pygments.formatters import HtmlFormatter   

print("Initalizing Data variables")
# Directory to store Minecraft server instances
INSTANCE_DIR = "instances"
SERVER_DIR = os.path.join(INSTANCE_DIR, "server")
VERSION_MANIFEST_URL = "https://launchermeta.mojang.com/mc/game/version_manifest.json"

# Forge and Fabric URLs
FORGE_INSTALLER_URL = "https://maven.minecraftforge.net/net/minecraftforge/forge/{version}/forge-{version}-installer.jar"
FABRIC_INSTALLER_URL = "https://meta.fabricmc.net/v2/versions/loader/{version}/{fabric_loader_version}/server/jar"

# Paper and Purpur URLs
PAPER_URL = "https://papermc.io/api/v2/projects/paper/versions/{version}/builds/{build}/downloads/paper-{version}-{build}.jar"
PURPUR_URL = "https://api.purpurmc.org/v2/purpur/{version}/{build}/download"

print("Initalizing storage variables...")
selected_instance = None

print("Initalizing Functions")
def find_minecraft_directory():
    # List of potential Minecraft installation directories
    minecraft_directories = [
        os.path.join(os.getenv("APPDATA"), ".minecraft"),  # Windows
        os.path.expanduser("~/Library/Application Support/minecraft"),  # macOS
        os.path.expanduser("~/.minecraft"),  # Linux
    ]
    
    for directory in minecraft_directories:
        if os.path.isdir(directory):
            return directory
    
    return None

def list_logs(logs_directory):
    """
    Lists all log files and compressed log files in the specified directory.

    Parameters:
    logs_directory (str): Path to the directory containing log files.

    Returns:
    list: List of log file names.
    """
    try:
        log_files = [file for file in os.listdir(logs_directory) if file.endswith('.log') or file.endswith('.gz')]
        return log_files
    except Exception as e:
        print(f"Error listing log files: {e}")
        return []

def open_folder(directory):
    try:
        os.startfile(directory)
    except Exception as e:
        print(f"Error opening folder: {e}")

def open_file(path):
    try:
        os.startfile(path)
    except Exception as e:
        print(f"Error opening file: {e}")

def reparse_log(logs_directory, parsed_logs_directory, log_file):
    """
    Parses a Minecraft server log file into HTML with custom styling.

    Parameters:
    logs_directory (str): Path to the directory containing log files.
    parsed_logs_directory (str): Path to the directory to save parsed log HTML files.
    log_file (str): Name of the log file to parse.

    Returns:
    None
    """
    try:
        # Read log content
        log_file_path = os.path.join(logs_directory, log_file)

        # Check if the log file is gzipped
        if log_file.endswith('.gz'):
            with gzip.open(log_file_path, 'rt', encoding='utf-8') as gz_file:
                log_content = gz_file.read()
        else:
            with open(log_file_path, 'r', encoding='utf-8') as file:
                log_content = file.read()

        # Regular expression pattern to match log lines
        log_pattern = re.compile(r'\[(.*?)\] \[(.*?)\/(.*?)\]: (.*)')

        # Prepare formatted log content
        formatted_log = []
        linenum = 0
        for line in log_content.splitlines():
            match = log_pattern.match(line)
            if match:
                log_time = match.group(1)
                log_source = match.group(2)
                log_level = match.group(3)
                log_message = match.group(4)
                linenum = linenum + 1

                # Determine log level and apply appropriate styling
                if log_level == "INFO":
                    styled_line = f'<p style="font-weight: bold; color: #0000FF;">{linenum}. [{log_time}] [{log_source}/{log_level}]: {log_message}</p>'
                elif log_level == "ERROR":
                    styled_line = f'<p style="font-weight: bold; color: #FF0000;">{linenum}. [{log_time}] [{log_source}/{log_level}]: {log_message}</p>'
                elif log_level == "WARN":
                    styled_line = f'<p style="font-weight: bold; color: #FFA500;">{linenum}. [{log_time}] [{log_source}/{log_level}]: {log_message}</p>'
                else:
                    styled_line = f'<p style="font-weight: bold;">{linenum}. [{log_time}] [{log_source}/{log_level}]: {log_message}</p>'  # Default style

                formatted_log.append(styled_line)

        # Join lines with appropriate HTML formatting
        formatted_log_content = '\n'.join(formatted_log)

        # Construct path for parsed log HTML file
        parsed_log_html_path = os.path.join(parsed_logs_directory, f"{log_file}.html")

        # Write HTML content to file
        with open(parsed_log_html_path, 'w', encoding='utf-8') as html_file:
            html_file.write(formatted_log_content)

        print(f"Parsed log saved to: {parsed_log_html_path}")

    except Exception as e:
        print(f"Error parsing log file '{log_file}': {e}")

def delete_log(logs_directory, parsed_logs_directory, log_file):
    """
    Deletes a log file and its parsed HTML counterpart (if exists).

    Parameters:
    logs_directory (str): Path to the directory containing log files.
    parsed_logs_directory (str): Path to the directory containing parsed log HTML files.
    log_file (str): Name of the log file to delete.

    Returns:
    None
    """
    try:
        # Delete original log file
        log_file_path = os.path.join(logs_directory, log_file)
        os.remove(log_file_path)
        print(f"Deleted log file: {log_file}")

        # Delete parsed HTML log file if exists
        parsed_log_html_path = os.path.join(parsed_logs_directory, f"{log_file}.html")
        if os.path.exists(parsed_log_html_path):
            os.remove(parsed_log_html_path)
            print(f"Deleted parsed log HTML: {parsed_log_html_path}")

    except Exception as e:
        print(f"Error deleting log file '{log_file}': {e}")

def log_manager(instance_path):
    """
    Manages Minecraft server logs including viewing, parsing, and deleting.

    Parameters:
    instance_path (str): Path to the Minecraft server instance directory.

    Returns:
    None
    """
    try:
        # Paths setup
        logs_directory = os.path.join(instance_path, 'logs')
        parsed_logs_directory = os.path.join(instance_path, 'SuperDiamondMCParsed-logs')

        if not os.path.exists(parsed_logs_directory):
            os.makedirs(parsed_logs_directory)

        while True:
            print("Logs")
            print("1. Select log")
            print("2. Open logs folder")
            print("3. Open parsed logs folder")
            print("0. Back")

            choice = input("Enter your choice: ")

            if choice == '1':
                # List log files
                log_files = list_logs(logs_directory)
                if log_files:
                    print("\n=== List of Log Files ===")
                    for idx, log_file in enumerate(log_files, start=1):
                        print(f"{idx}. {log_file}")
                    selection = input("Enter log file number (0 to cancel): ")
                    if selection.isdigit() and 1 <= int(selection) <= len(log_files):
                        selected_log = log_files[int(selection) - 1]

                        while True:
                            print(f"Selected Log: {selected_log}")
                            print("1. Reparse log")
                            print("2. Delete log")
                            print("3. Open parsed log")
                            print("0. Back to log selection")

                            sub_choice = input("Enter your choice: ")

                            if sub_choice == '1':
                                print("Re-parsing log...")
                                reparse_log(logs_directory, parsed_logs_directory, selected_log)

                            elif sub_choice == '2':
                                print("Deleting log...")
                                delete_log(logs_directory, parsed_logs_directory, selected_log)

                            elif sub_choice == '3':
                                print("Opening parsed log...")
                                parsed_log_html_path = os.path.join(parsed_logs_directory, f"{selected_log}.html")
                                if os.path.exists(parsed_log_html_path):
                                    open_file(parsed_log_html_path)
                                else:
                                    print("Parsed log HTML not found.")

                            elif sub_choice == '0':
                                break

                            else:
                                print("Invalid choice. Please enter a valid option.")

                    elif selection == '0':
                        continue
                    else:
                        print("Invalid selection. Please enter a valid number.")

            elif choice == '2':
                open_folder(logs_directory)

            elif choice == '3':
                open_folder(parsed_logs_directory)

            elif choice == '0':
                break

            else:
                print("Invalid choice. Please enter a valid option.")

    except Exception as e:
        print(f"Error managing Minecraft logs: {e}")

def get_version_download_data(version):
    minecraft_directory = find_minecraft_directory()
    if not minecraft_directory:
        print("Minecraft directory not found.")
        return None
    
    # Construct file path for version.json
    version_json_path = os.path.join(minecraft_directory, "versions", version, f"{version}.json")
    
    try:
        # Check if the version JSON file exists
        if os.path.isfile(version_json_path):
            with open(version_json_path, "r") as f:
                data = json.load(f)
                if "downloads" in data:
                    server_url = data["downloads"].get("server", {}).get("url")
                    return {"server": {"url": server_url, "file": f"{version}.jar"}}
                else:
                    print(f"No 'downloads' key found in {version_json_path}")
                    return None
        else:
            print(f"Version JSON file not found: {version_json_path}")
            return None
        
    except FileNotFoundError:
        print(f"File not found: {version_json_path}")
        return None
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON in {version_json_path}: {e}")
        return None
    except Exception as e:
        print(f"Error reading file {version_json_path}: {e}")
        return None

def find_new_crash_reports(crash_reports_folder):
    """
    Checks for crash reports that don't have the "SuperDiamondMCRead_" prefix.

    Parameters:
    crash_reports_folder (str): The path to the Minecraft crash-reports folder.

    Returns:
    list: A list of full paths to crash reports that don't have the "SuperDiamondMCRead_" prefix.
          Returns False if there are no such reports.
    """
    unprocessed_reports = []
    files = os.listdir(crash_reports_folder)
    
    for file in files:
        if (file.endswith('.txt') or file.endswith('.log')) and not file.startswith("SuperDiamondMCRead_"):
            unprocessed_reports.append(os.path.join(crash_reports_folder, file))
    
    return unprocessed_reports if unprocessed_reports else False

def mark_crash_reports(crash_reports_folder):
    """
    Adds the "SuperDiamondMCRead_" prefix to all crash reports that don't have it.

    Parameters:
    crash_reports_folder (str): The path to the Minecraft crash-reports folder.
    """
    unprocessed_reports = check_for_unprocessed_crash_reports(crash_reports_folder)
    
    if unprocessed_reports:
        for report in unprocessed_reports:
            new_path = os.path.join(crash_reports_folder, "SuperDiamondMCRead_" + os.path.basename(report))
            os.rename(report, new_path)

def download_file(url, dest):
    """Download a file from a URL to a destination path"""
    response = requests.get(url, stream=True)
    with open(dest, 'wb') as f:
        shutil.copyfileobj(response.raw, f)
    print(f"Downloaded {url} to {dest}")

def install_forge_server(version, instance_path):
    """Install Forge server based on version"""
    forge_installer_url = FORGE_INSTALLER_URL.format(version=version)
    forge_installer_path = os.path.join(instance_path, "forge-installer.jar")
    download_file(forge_installer_url, forge_installer_path)
    
    print(f"Installing Forge server version {version}...")
    try:
        subprocess.run(["java", "-jar", forge_installer_path, "--installServer"], cwd=instance_path, check=True)
        print(f"Forge server version {version} installed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error installing Forge server version {version}: {e}")

def install_fabric_server(version, fabric_loader_version, instance_path):
    """Install Fabric server based on version and loader version"""
    fabric_server_url = FABRIC_INSTALLER_URL.format(version=version, fabric_loader_version=fabric_loader_version)
    fabric_server_path = os.path.join(instance_path, "fabric-server.jar")
    download_file(fabric_server_url, fabric_server_path)
    
    print(f"Installing Fabric server version {version}...")
    try:
        shutil.move(fabric_server_path, os.path.join(instance_path, "server.jar"))
        print(f"Fabric server version {version} installed successfully.")
    except Exception as e:
        print(f"Error installing Fabric server version {version}: {e}")

def install_paper_server(version, build, instance_path):
    """Install Paper server based on version and build"""
    paper_url = PAPER_URL.format(version=version, build=build)
    paper_server_path = os.path.join(instance_path, "paper-server.jar")
    download_file(paper_url, paper_server_path)
    
    print(f"Installing Paper server version {version} build {build}...")
    try:
        shutil.move(paper_server_path, os.path.join(instance_path, "server.jar"))
        print(f"Paper server version {version} build {build} installed successfully.")
    except Exception as e:
        print(f"Error installing Paper server version {version} build {build}: {e}")

def install_purpur_server(version, build, instance_path):
    """Install Purpur server based on version and build"""
    purpur_url = PURPUR_URL.format(version=version, build=build)
    purpur_server_path = os.path.join(instance_path, "purpur-server.jar")
    download_file(purpur_url, purpur_server_path)
    
    print(f"Installing Purpur server version {version} build {build}...")
    try:
        shutil.move(purpur_server_path, os.path.join(instance_path, "server.jar"))
        print(f"Purpur server version {version} build {build} installed successfully.")
    except Exception as e:
        print(f"Error installing Purpur server version {version} build {build}: {e}")

def index_exists(lst, index):
    return 0 <= index < len(lst)

def get_file_type(filename):
    # Split the filename into root and extension
    root, ext = os.path.splitext(filename)
    return ext

# Function to extract basename from URL
def extract_basename_from_url(url):
    # Parse the URL to get the path
    parsed_url = urlparse(url)
    # Extract the basename from the path
    basename = os.path.basename(parsed_url.path)
    return basename

def install_custom_server(instance_path, data):
    try:
     if data[1] == "file":
      if index_exists(data, 2):
       file = data[2]
      else:
       file = select_custom_installation()
      if get_file_type(os.path.basename(file)) == ".jar":
       shutil.copy2(file, os.path.join(instance_path, "server.jar"))
      elif get_file_type(os.path.basename(file)) == ".zip":
       shutil.copy2(file, os.path.join(instance_path, "server.zip"))
       extract_zip(os.path.join(instance_path, "server.zip"), instance_path)
      else:
       print("Unsupported file type. .zip and .jar only!")
     elif data[1] == "web":
      if get_file_type(extract_basename_from_url(data[2])) == ".jar":
       download_file(data[2], os.path.join(instance_path, "server.jar"))
      elif get_file_type(extract_basename_from_url(data[2])) == ".zip":
       download_file(data[2], os.path.join(instance_path, "server.zip"))
       extract_zip(os.path.join(instance_path, "server.zip"), instance_path)
      else:
       print("Unsupported file type. .zip and .jar only!")
    except Exception as e:
     print("An error accoured: ", e)
       

def read_properties(file_path):
    """Read a .properties file and convert it to a dictionary"""
    properties = {}
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line and not line.startswith('#'):
                key, value = line.split('=', 1)
                properties[key.strip()] = value.strip()
    return properties

def write_properties(properties, file_path):
    """Write a dictionary to a .properties file"""
    with open(file_path, 'w') as file:
        # Write the header comments
        file.write("#Minecraft server properties\n")
        from datetime import datetime
        file.write(f"#{datetime.now().strftime('%a %b %d %H:%M:%S %Z %Y')}\n")
        # Write the properties
        for key, value in properties.items():
            file.write(f"{key}={value}\n")

def get_version_world_format(version):
    if version.startswith("vanilla-") or version.startswith("fabric-"):
     return 0
    elif version.startswith("paper-") or version.startswith("purpur-"):
     return 1
    else:
     return None

def change_version(name, version, instance_type):
        instance_path = os.path.join(instance_type, name)
        if instance_type == SERVER_DIR:
            server_jar_path = os.path.join(instance_path, "server.jar")
            
            # Handle vanilla server installation
            if version.startswith("vanilla-"):
                vanilla_version = version.split("-")[1]
                download_data = get_version_download_data(vanilla_version)
                if download_data and download_data["server"]:
                    download_file(download_data["server"]["url"], server_jar_path)
                else:
                    print(f"No server file found for version {vanilla_version}")
                    return
            else:
                # Install Fabric, Paper, Purpur or custom based on version prefix
                if version.startswith("fabric-"):
                    fabric_loader_version = version.split("-")[1]
                    install_fabric_server(version.split("-")[1], fabric_loader_version, instance_path)
                elif version.startswith("paper-"):
                    paper_version = version.split("-")[1]
                    paper_build = version.split("-")[2]
                    install_paper_server(paper_version, paper_build, instance_path)
                elif version.startswith("purpur-"):
                    purpur_version = version.split("-")[1]
                    purpur_build = version.split("-")[2]
                    install_purpur_server(purpur_version, purpur_build, instance_path)
                elif version.startswith("custom-"):
                    data = version.split("-")
                    install_custom_server(instance_path, data)
                else:
                    print("Version type not found. keeping current version.")
            
        if(get_version_world_format(get_instance_version(name, SERVER_DIR)) == 1):
          if(get_version_world_format(version) == 0):
            worldconvert = input("Would you like to auto reformat the world for the version change? (Y/N): ")
            if(worldconvert.lower() == "y"):
             print("reformating from world format 1 to format 0")
             if(os.path.exists(os.path.join(instance_path, "world_nether/DIM-1")) and os.path.isdir(os.path.join(instance_path, "world_nether/DIM-1"))):
              delete_directory(os.path.join(instance_path, "world/DIM-1"))
              shutil.copytree(os.path.join(instance_path, "world_nether/DIM-1"), os.path.join(instance_path, "world/DIM-1"))
             if(os.path.exists(os.path.join(instance_path, "world_the_end/DIM1")) and os.path.isdir(os.path.join(instance_path, "world_the_end/DIM1"))):
              delete_directory(os.path.join(instance_path, "world/DIM1"))
              shutil.copytree(os.path.join(instance_path, "world_the_end/DIM1"), os.path.join(instance_path, "world/DIM1"))
             print("Sucesfully reformated from world format 1 to format 0")
        elif(get_version_world_format(get_instance_version(name, SERVER_DIR)) == 0):
          if(get_version_world_format(version) == 1):
            worldconvert = input("Would you like to auto reformat the world for the version change? (Y/N): ")
            if(worldconvert.lower() == "y"):
             print("reformating from world format 0 to format 1")
             if(os.path.exists(os.path.join(instance_path, "world/DIM-1")) and os.path.isdir(os.path.join(instance_path, "world/DIM-1"))):
              delete_directory(os.path.join(instance_path, "world_nether/DIM-1"))
              shutil.copytree(os.path.join(instance_path, "world/DIM-1"), os.path.join(instance_path, "world_nether/DIM-1"))
             if(os.path.exists(os.path.join(instance_path, "world/DIM1")) and os.path.isdir(os.path.join(instance_path, "world/DIM1"))):
              delete_directory(os.path.join(instance_path, "world_the_end/DIM1"))
              shutil.copytree(os.path.join(instance_path, "world/DIM1"), os.path.join(instance_path, "world_the_end/DIM1"))
             print("Sucesfully reformated from world format 0 to format 1")
        
        # Save the version info
        with open(os.path.join(instance_path, f"version.json"), 'w') as f:
            json.dump({"version": version}, f)

def create_instance(name, version, instance_type):
    """Create a new Minecraft server instance with a specific version"""
    instance_path = os.path.join(instance_type, name)
    if not os.path.exists(instance_path):
        os.makedirs(instance_path)
        
        if instance_type == SERVER_DIR:
            server_jar_path = os.path.join(instance_path, "server.jar")

            # Handle vanilla server installation
            if version.startswith("vanilla-"):
                vanilla_version = version.split("-")[1]
                download_data = get_version_download_data(vanilla_version)
                if download_data and download_data["server"]:
                    download_file(download_data["server"]["url"], server_jar_path)
                else:
                    print(f"No server file found for version {vanilla_version}")
                    return
            else:
                # Install Fabric, Paper, Purpur or custom based on version prefix
                if version.startswith("fabric-"):
                    fabric_loader_version = version.split("-")[1]
                    install_fabric_server(version.split("-")[1], fabric_loader_version, instance_path)
                elif version.startswith("paper-"):
                    paper_version = version.split("-")[1]
                    paper_build = version.split("-")[2]
                    install_paper_server(paper_version, paper_build, instance_path)
                elif version.startswith("purpur-"):
                    purpur_version = version.split("-")[1]
                    purpur_build = version.split("-")[2]
                    install_purpur_server(purpur_version, purpur_build, instance_path)
                elif version.startswith("custom-"):
                    data = version.split("-")
                    install_custom_server(instance_path, data)
                else:
                    print("Version type not found. if you tried to make a vanilla server. try vanilla-", version)
        

        os.mkdir(os.path.join(instance_path, f"SuperDiamondMCParsed-crash-reports"))
        os.mkdir(os.path.join(instance_path, f"SuperDiamondMCParsed-crash-report-views"))
        os.mkdir(os.path.join(instance_path, f"SuperDiamondMCParsed-logs"))
        # Save the version info
        with open(os.path.join(instance_path, f"version.json"), 'w') as f:
            json.dump({"version": version}, f)
        
        # Create the 'world' directory
        download_file("https://alexidians.github.io/Super-Diamond-MC/instancedata/defaults/server.properties", os.path.join(instance_path, "server.properties"))
        os.makedirs(os.path.join(instance_path, "world"))
        print(f"Created new server instance: {name} with version: {version}")
    else:
        print(f"Instance {name} already exists")

def list_instances(instance_type):
    """List all Minecraft server instances"""
    if not os.path.exists(instance_type):
        os.makedirs(instance_type)
    instances = os.listdir(instance_type)
    if instances:
        for instance in instances:
            version = get_instance_version(instance, instance_type)
            print(f"{instance} (version: {version})")
    else:
        print("No instances found")

def delete_instance(name, instance_type):
    """Delete a Minecraft server instance"""
    instance_path = os.path.join(instance_type, name)
    if os.path.exists(instance_path):
        shutil.rmtree(instance_path)
        print(f"Deleted server instance: {name}")
    else:
        print(f"Server instance {name} does not exist")

def get_instance_version(name, instance_type):
    """Get the version of a specific Minecraft server instance"""
    instance_path = os.path.join(instance_type, name)
    version_file = os.path.join(instance_path, f"version.json")
    if os.path.exists(version_file):
        with open(version_file, 'r') as f:
            data = json.load(f)
        return data.get('version', 'unknown')
    return 'unknown'

def agree_to_eula(eula_file_path):
    """Agree to Minecraft EULA by writing 'eula=true' to eula.txt"""
    try:
        with open(eula_file_path, "w") as f:
            f.write("eula=true\n")
        print("You have agreed to the Minecraft EULA.")
        return True
    except Exception as e:
        print(f"Error agreeing to EULA: {e}")
        return False

def is_eula_agreed(eula_file_path):
    """Check if Minecraft EULA is agreed by reading eula.txt"""
    try:
        with open(eula_file_path, "r") as f:
            for line in f:
                if "eula=true" in line.lower():
                    return True
        return False
    except FileNotFoundError:
        print(f"EULA file not found: {eula_file_path}")
        return False
    except Exception as e:
        print(f"Error reading EULA file: {e}")
        return False

def parse_server_crash_report(file_path, output_file):
    """
    Parses a Minecraft server crash report and creates a detailed description of the issues.

    Parameters:
    file_path (str): The path to the crash report file.
    output_file (str): The path to save the JSON output.

    Returns:
    dict: A dictionary containing the extracted information and detailed description.
    """
    crash_info = {
        "timestamp": "",
        "description": "",
        "detailed_description": "",
        "plugins": "",
        "mods": ""
    }

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            is_plugins_list = False
            is_mods_list = False

            for line in lines:
                if "---- Minecraft Crash Report ----" in line:
                    continue

                if "Time:" in line:
                    crash_info["timestamp"] = line.split("Time:")[1].strip()

                if "Description:" in line:
                    crash_info["description"] = line.split("Description:")[1].strip()

                if "Plugins:" in line:
                    is_plugins_list = True
                    crash_info["plugins"] = ""

                if is_plugins_list:
                    crash_info["plugins"] += line
                    if line.strip() == "":
                        is_plugins_list = False

                if "Mods:" in line:
                    is_mods_list = True
                    crash_info["mods"] = ""

                if is_mods_list:
                    crash_info["mods"] += line
                    if line.strip() == "":
                        is_mods_list = False

        # Remove empty keys
        crash_info = {k: v for k, v in crash_info.items() if v}

        # Save to JSON file
        with open(output_file, 'w', encoding='utf-8') as json_file:
            json.dump(crash_info, json_file, indent=4)

        return crash_info

    except Exception as e:
        print(f"An error occurred while parsing the crash report: {e}")
        return None

def create_or_update_view_file(parsed_data, view_file_path):
    """
    Creates or updates a view file with parsed crash report data.

    Parameters:
    parsed_data (dict): Parsed crash report data as a dictionary.
    view_file_path (str): Path to the view file.

    Returns:
    None
    """
    try:
        with open(view_file_path, 'w', encoding='utf-8') as view_file:
            view_file.write(f"Timestamp: {parsed_data.get('timestamp', 'N/A')}\n")
            view_file.write(f"Description: {parsed_data.get('description', 'N/A')}\n")
            view_file.write(f"Plugins: {parsed_data.get('plugins', 'N/A')}\n")
            view_file.write(f"Mods: {parsed_data.get('mods', 'N/A')}\n")
        print(f"View file created or updated: {view_file_path}")
    except Exception as e:
        print(f"Error creating or updating view file: {e}")


def crash_report_manager(instance_path):
    crash_reports_folder = os.path.join(instance_path, "crash-reports")
    parsed_crash_reports_folder = os.path.join(instance_path, "SuperDiamondMCParsed-crash-reports")
    view_folder = os.path.join(instance_path, "SuperDiamondMCParsed-crash-report-views")

    while True:
        print("\nCrash Reports:")
        print("0. Exit Manager")
        print("1. Select a crash report to manage")
        print("2. Open crash reports folder")
        print("3. Open parsed crash reports folder")

        choice = input("Enter your choice: ")

        if choice == "0":
            print("Exiting Crash Report Manager.")
            break
        
        elif choice == "1":
            # List available crash reports
            print("\nAvailable Crash Reports:")
            reports = os.listdir(crash_reports_folder)
            for idx, report in enumerate(reports):
                print(f"{idx+1}. {report}")

            if not reports:
                print("No crash reports found.")
                continue

            try:
                selection = int(input("Select a crash report by number (or 0 to cancel): "))
                if selection == 0:
                    continue
                elif 1 <= selection <= len(reports):
                    selected_report = reports[selection - 1]
                    print(f"\nSelected Crash Report: {selected_report}")
                    
                    # Construct paths
                    crash_report_path = os.path.join(crash_reports_folder, selected_report)
                    parsed_crash_report_path = os.path.join(parsed_crash_reports_folder, selected_report + ".json")
                    view_file_path = os.path.join(view_folder, selected_report + ".json.txt")

                    while True:
                        print("\nActions:")
                        print("1. View crash report file in text editor")
                        print("2. View parsed crash report")
                        print("3. Delete crash report and parsed data")
                        print("4. Reparse crash report")
                        print("5. Unselect crash report")
                        
                        action = input("Enter your action choice: ")

                        if action == "1":
                            # Open crash report in text editor
                            subprocess.run(["notepad.exe", crash_report_path])

                        elif action == "2":
                            # View parsed crash report
                            if os.path.exists(parsed_crash_report_path):
                                with open(parsed_crash_report_path, 'r', encoding='utf-8') as file:
                                    parsed_data = json.load(file)
                                # Display parsed data
                                print(f"Timestamp: {parsed_data.get('timestamp', 'N/A')}")
                                print(f"Description: {parsed_data.get('description', 'N/A')}")
                                print(f"Plugins: {parsed_data.get('plugins', 'N/A')}")
                                print(f"Mods: {parsed_data.get('mods', 'N/A')}")

                                # Check if the parsed crash report is too large for console display
                                if len(json.dumps(parsed_data, indent=2)) > 10000:
                                    print(f"Parsed crash report is too large. Opening in text editor: {view_file_path}")
                                    create_or_update_view_file(parsed_data, view_file_path)
                                    subprocess.run(["notepad.exe", view_file_path])
                            else:
                                print("Parsed crash report not found.")

                        elif action == "3":
                            # Delete crash report and parsed data
                            if os.path.exists(crash_report_path):
                                os.remove(crash_report_path)
                                print(f"Deleted crash report: {selected_report}")
                            if os.path.exists(parsed_crash_report_path):
                                os.remove(parsed_crash_report_path)
                                print(f"Deleted parsed crash report: {selected_report}.json")
                            if os.path.exists(view_file_path):
                                os.remove(view_file_path)
                                print(f"Deleted view file: {selected_report}.json.txt")
                            print("Deleted all associated files.")

                        elif action == "4":
                            # Reparse crash report
                            print(f"Re-parsing crash report: {selected_report}")
                            parsed_data = parse_server_crash_report(crash_report_path, parsed_crash_report_path)
                            if parsed_data:
                                print("Successfully re-parsed crash report.")
                                create_or_update_view_file(parsed_data, view_file_path)

                        elif action == "5":
                            # Unselect crash report and return to selection menu
                            print("Unselected crash report.")
                            break

                        else:
                            print("Invalid choice. Please enter a valid action.")

            except ValueError:
                print("Invalid input. Please enter a valid number.")

        elif choice == "2":
            # Open crash reports folder
            subprocess.run(["explorer", crash_reports_folder])

        elif choice == "3":
            # Open parsed crash reports folder
            subprocess.run(["explorer", parsed_crash_reports_folder])

        else:
            print("Invalid choice. Please enter a valid option.")

def launch_instance(name, instance_type, port):
    """Launch a Minecraft server instance"""
    version = get_instance_version(name, instance_type)
    if version == 'unknown':
        print(f"Cannot launch instance {name} because its version is unknown")
        return
    instance_path = os.path.join(instance_type, name)
    server_jar_path = os.path.join(instance_path, "server.jar")
    if not os.path.exists(server_jar_path):
        print(f"Server jar not found for instance {name}")
        return
    print(f"Launching server instance {name} with version {version}...")
    try:
        subprocess.run(["java", "-jar", os.path.abspath(server_jar_path), "--port", port], cwd=instance_path, check=True)
        # Check if EULA is agreed
        eula_file_path = os.path.join(instance_path, "eula.txt")
        if find_new_crash_reports(os.path.join(instance_path, "crash-reports")):
            crashreport = find_new_crash_reports(os.path.join(instance_path, "crash-reports"))
            mark_crash_reports(os.path.join(instance_path, "crash-reports"))
            crashreportmarked = os.path.join(os.path.dirname(crashreport), "SuperDiamondMCRead_") + basename(crashreport)
            print("Oh no! the server has crashed. Crash Report is at: " + crashreportmarked)
            parsecrashreport = input("Would you like to parse the crash report now?: ")
            if parsecrashreport.lower() == "y":
              print("Parsing Crash Report...")
              parse_server_crash_report(crashreportmarked, os.path.join(instance_path, "SuperDiamondMCParsed-crash-reports", basename(crashreportmarked)))
              print("Crash Report Parsed. view it in the crash reports category.")

        if not is_eula_agreed(eula_file_path):
            agree = input("Do you agree to the Minecraft EULA? (type 'yes' to agree): ")
            if agree.lower() == "yes":
                agree_to_eula(eula_file_path)
                print("Starting server...")
                launch_instance(name, instance_type, port)
            else:
                print("You must agree to the Minecraft EULA to run the server.")
    except subprocess.CalledProcessError as e:
        print(f"Error launching server instance {name}: {e}")

def add_world_to_instance(instance_name, instance_type):
    """Add a world save to a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    world_folder = os.path.join(instance_path, "world")
    if not os.path.exists(instance_path):
        print(f"Instance {instance_name} does not exist.")
        return
    
    world_path = eg.diropenbox(title="Select the world folder or .zip file")
    if not world_path:
        print("No folder or .zip file selected or operation canceled.")
        return
    
    try:
        if os.path.isdir(world_path):
            shutil.copytree(world_path, os.path.join(instance_path, "world"))
            print(f"Added world from folder {world_path} to instance {instance_name}.")
        elif zipfile.is_zipfile(world_path):
            with zipfile.ZipFile(world_path, 'r') as zip_ref:
                zip_ref.extractall(world_folder)
            print(f"Extracted and added world from {world_path} to instance {instance_name}.")
        else:
            print("Unsupported file type. Please select a folder or .zip file.")
    except Exception as e:
        print(f"Error adding world to instance {instance_name}: {e}")

def delete_world(instance_name, instance_type):
    """Delete the world save from a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    world_folder = os.path.join(instance_path, "world")
    if os.path.exists(world_folder) and os.path.isdir(world_folder):
        shutil.rmtree(world_folder)
        print(f"Deleted world save from instance {instance_name}.")
    else:
        print(f"No world save found in instance {instance_name}.")

def select_data_pack_path():
    """Open a file dialog to select a data pack folder or zip file and return its path"""
    path = eg.fileopenbox(filetypes=["*.zip"], title="Select a .zip file") or eg.diropenbox(title="Select a data pack folder")
    return path

def select_custom_installation():
    """Open a file dialog to select a data pack folder or zip file and return its path"""
    path = eg.fileopenbox(filetypes=["*.zip", "*.jar"], title="Select a .zip or .jar file")
    return path

def add_data_pack_to_instance(instance_name, instance_type):
    """Add a data pack (either folder or .zip) to a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    if not os.path.exists(instance_path):
        print(f"Instance {instance_name} does not exist.")
        return
    
    data_pack_path = select_data_pack_path()
    if not data_pack_path:
        print("No file or folder selected or operation canceled.")
        return
    
    try:
        if os.path.isdir(data_pack_path):
            shutil.copytree(data_pack_path, os.path.join(instance_path, "datapacks", os.path.basename(data_pack_path)))
            print(f"Added data pack from folder {data_pack_path} to instance {instance_name}.")
        elif zipfile.is_zipfile(data_pack_path):
            with zipfile.ZipFile(data_pack_path, 'r') as zip_ref:
                zip_ref.extractall(os.path.join(instance_path, "world/datapacks"))
            print(f"Extracted and added data pack from {data_pack_path} to instance {instance_name}.")
        else:
            print("Unsupported file type. Please select a folder or .zip file.")
    except Exception as e:
        print(f"Error adding data pack to instance {instance_name}: {e}")

def delete_data_pack_from_instance(instance_name, instance_type):
    """Delete a data pack from a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    datapacks_folder = os.path.join(instance_path, "world/datapacks")
    if os.path.exists(datapacks_folder) and os.path.isdir(datapacks_folder):
        print("Data packs in instance:")
        datapacks = os.listdir(datapacks_folder)
        for pack in datapacks:
            print(f"- {pack}")
        pack_name = input("Enter data pack name to delete (exact name): ")
        pack_path = os.path.join(datapacks_folder, pack_name)
        if os.path.exists(pack_path):
            shutil.rmtree(pack_path)
            print(f"Deleted data pack {pack_name} from instance {instance_name}.")
        else:
            print(f"No data pack named {pack_name} found in instance {instance_name}.")
    else:
        print(f"No data packs found in instance {instance_name}.")

def list_data_packs(instance_name, instance_type):
    """List all data packs in a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    datapacks_folder = os.path.join(instance_path, "world/datapacks")
    if os.path.exists(datapacks_folder) and os.path.isdir(datapacks_folder):
        print(f"Data packs in instance {instance_name}:")
        datapacks = os.listdir(datapacks_folder)
        for pack in datapacks:
            print(f"- {pack}")
    else:
        print(f"No data packs found in instance {instance_name}.")

def select_plugin_path():
    """Open a file dialog to select a plugin .jar file and return its path"""
    path = eg.fileopenbox(filetypes=["*.jar"], title="Select a .jar file")
    return path

def add_plugin_to_instance(instance_name, instance_type):
    """Add a plugin (.jar) to a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    if not os.path.exists(instance_path):
        print(f"Instance {instance_name} does not exist.")
        return
    
    plugins_folder = os.path.join(instance_path, "plugins")
    if not os.path.exists(plugins_folder):
        os.makedirs(plugins_folder)

    plugin_path = select_plugin_path()
    if not plugin_path:
        print("No file selected or operation canceled.")
        return
    
    try:
        if plugin_path.endswith('.jar'):
            shutil.copy(plugin_path, plugins_folder)
            print(f"Added plugin {os.path.basename(plugin_path)} to instance {instance_name}.")
        else:
            print("Unsupported file type. Please select a .jar file.")
    except Exception as e:
        print(f"Error adding plugin to instance {instance_name}: {e}")

def delete_plugin_from_instance(instance_name, instance_type):
    """Delete a plugin from a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    plugins_folder = os.path.join(instance_path, "plugins")
    if os.path.exists(plugins_folder) and os.path.isdir(plugins_folder):
        print("Plugins in instance:")
        plugins = [f for f in os.listdir(plugins_folder) if f.endswith('.jar')]
        for plugin in plugins:
            print(f"- {plugin}")
        plugin_name = input("Enter plugin name to delete (exact name, including .jar): ")
        plugin_path = os.path.join(plugins_folder, plugin_name)
        if os.path.exists(plugin_path):
            os.remove(plugin_path)
            print(f"Deleted plugin {plugin_name} from instance {instance_name}.")
        else:
            print(f"No plugin named {plugin_name} found in instance {instance_name}.")
    else:
        print(f"No plugins found in instance {instance_name}.")

def list_plugins(instance_name, instance_type):
    """List all plugins in a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    plugins_folder = os.path.join(instance_path, "plugins")
    if os.path.exists(plugins_folder) and os.path.isdir(plugins_folder):
        print(f"Plugins in instance {instance_name}:")
        plugins = [f for f in os.listdir(plugins_folder) if f.endswith('.jar')]
        for plugin in plugins:
            print(f"- {plugin}")
    else:
        print(f"No plugins found in instance {instance_name}.")

def select_mod_path():
    """Open a file dialog to select a mod .jar file and return its path"""
    path = eg.fileopenbox(filetypes=["*.jar"], title="Select a .jar file")
    return path

def add_mod_to_instance(instance_name, instance_type):
    """Add a mod (.jar) to a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    if not os.path.exists(instance_path):
        print(f"Instance {instance_name} does not exist.")
        return
    
    mods_folder = os.path.join(instance_path, "mods")
    if not os.path.exists(mods_folder):
        os.makedirs(mods_folder)

    mod_path = select_mod_path()
    if not mod_path:
        print("No file selected or operation canceled.")
        return
    
    try:
        if mod_path.endswith('.jar'):
            shutil.copy(mod_path, mods_folder)
            print(f"Added mod {os.path.basename(mod_path)} to instance {instance_name}.")
        else:
            print("Unsupported file type. Please select a .jar file.")
    except Exception as e:
        print(f"Error adding mod to instance {instance_name}: {e}")

def delete_mod_from_instance(instance_name, instance_type):
    """Delete a mod from a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    mods_folder = os.path.join(instance_path, "mods")
    if os.path.exists(mods_folder) and os.path.isdir(mods_folder):
        print("Mods in instance:")
        mods = [f for f in os.listdir(mods_folder) if f.endswith('.jar')]
        for mod in mods:
            print(f"- {mod}")
        mod_name = input("Enter mod name to delete (exact name, including .jar): ")
        mod_path = os.path.join(mods_folder, mod_name)
        if os.path.exists(mod_path):
            os.remove(mod_path)
            print(f"Deleted mod {mod_name} from instance {instance_name}.")
        else:
            print(f"No mod named {mod_name} found in instance {instance_name}.")
    else:
        print(f"No mods found in instance {instance_name}.")

def list_mods(instance_name, instance_type):
    """List all mods in a Minecraft server instance"""
    instance_path = os.path.join(instance_type, instance_name)
    mods_folder = os.path.join(instance_path, "mods")
    if os.path.exists(mods_folder) and os.path.isdir(mods_folder):
        print(f"Mods in instance {instance_name}:")
        mods = [f for f in os.listdir(mods_folder) if f.endswith('.jar')]
        for mod in mods:
            print(f"- {mod}")
    else:
        print(f"No mods found in instance {instance_name}.")

def set_max_world_size(propertiesfile, maxsize):
    properties = read_properties(propertiesfile)
    properties["max-world-size"] = maxsize
    write_properties(properties, propertiesfile)

def set_max_buildheight(propertiesfile, maxbuildheight):
    properties = read_properties(propertiesfile)
    properties["max-build-height"] = maxbuildheight
    write_properties(properties, propertiesfile)

def set_max_players(propertiesfile, maxplayers):
    properties = read_properties(propertiesfile)
    properties["max-players"] = maxplayers
    write_properties(properties, propertiesfile)

def set_motd(propertiesfile, motd):
    properties = read_properties(propertiesfile)
    properties["motd"] = motd
    write_properties(properties, propertiesfile)

def set_default_operator_permission_level(propertiesfile, defaultoppermlevel):
    properties = read_properties(propertiesfile)
    properties["op-permission-level"] = defaultoppermlevel
    write_properties(properties, propertiesfile)

def set_network_compression_treshold(propertiesfile, nwcomptreshold):
    properties = read_properties(propertiesfile)
    properties["network-compression-threshold"] = nwcomptreshold
    write_properties(properties, propertiesfile)

def set_player_idle_timeout(propertiesfile, idletimeout):
    properties = read_properties(propertiesfile)
    properties["player-idle-timeout"] = idletimeout
    write_properties(properties, propertiesfile)

def set_default_gamemode(propertiesfile, gamemodenum):
    properties = read_properties(propertiesfile)
    properties["gamemode"] = gamemodenum
    write_properties(properties, propertiesfile)

def set_server_icon(instance_path):
    """Set server icon for a Minecraft server instance"""
    try:
        print("Icon requirements:")
        print("Must be a 1:1 Ratio to prevent server rendering errors.")
        print("Must be 64x64 to prevent server rendering errors.")
        input("Press enter to continue")
        icon_path = eg.fileopenbox(title="Select a 64x64 PNG icon file for the server.")
        if icon_path:
            if not icon_path.endswith('.png'):
                print("Please select a PNG file.")
                return
            shutil.copy2(icon_path, os.path.join(instance_path, "server-icon.png"))
        else:
            print("No file selected or operation canceled.")
    except Exception as e:
        print(f"An error occurred: {e}")

def set_server_resourcepack(instance_path):
    """Set server resourcepack for a Minecraft server instance"""
    try:
        
        icon_path = eg.fileopenbox(title="Select a .zip resourcepack for the server.")
        if icon_path:
            if not icon_path.endswith('.zip'):
                print("Please select a ZIP file.")
                return
            resourcepackpath = "resource_packs/SuperDiamondMC_Sys/" + generate_id() + ".zip"
            shutil.copy2(icon_path, os.path.join(instance_path, resourcepackpath))
            properties = read_properties(os.path.join(instance_path, "server.properties"))
            properties["resource-pack"] = resourcepackpath
            write_properties(properties, os.path.join(instance_path, "server.properties"))
        else:
            print("No file selected or operation canceled.")
    except Exception as e:
        print(f"An error occurred: {e}")

def remove_server_resourcepack(instance_path):
    os.path.unlink(os.path.join(instance_path, "resourcepacks/serverresourcepack.zip"))
    properties = read_properties(os.path.join(instance_path, "server.properties"))
    properties["resource-pack"] = ""
    write_properties(properties, os.path.join(instance_path, "server.properties"))   

def generate_id():
    # Generate a UUID based on the current timestamp
    return str(uuid.uuid1())

def add_operator_to_ops(username, level, ops_file='ops.json'):
    # Fetch the official UUID for the username
    try:
        user_uuid = fetch_uuid(username, True)
    except Exception as e:
        print(e)
        return

    # Load the existing ops.json file
    try:
        with open(ops_file, 'r') as file:
            ops = json.load(file)
    except FileNotFoundError:
        ops = []

    # Create a new operator entry
    new_operator = {
        "uuid": user_uuid,
        "name": username,
        "level": level,
        "bypassesPlayerLimit": False
    }

    # Check if the user already exists in the ops list
    for op in ops:
        if op["uuid"] == user_uuid:
            print(f"User {username} is already an operator.")
            return

    # Add the new operator to the list
    ops.append(new_operator)

    # Save the updated ops.json file
    with open(ops_file, 'w') as file:
        json.dump(ops, file, indent=2)

    print(f"Added operator {username} with level {level} to {ops_file}")

def fetch_uuid(username, formating=True):
    """Fetches the UUID for a given Minecraft username from the Mojang API and formats it with dashes."""
    response = requests.get(f"https://api.mojang.com/users/profiles/minecraft/{username}")
    if response.status_code == 200:
        data = response.json()
        uuid = data['id']
        if formating:
         formatted_uuid = f"{uuid[:8]}-{uuid[8:12]}-{uuid[12:16]}-{uuid[16:20]}-{uuid[20:]}"
         return formatted_uuid
        else:
         return uuid
    else:
        raise Exception(f"Failed to fetch UUID for username: {username}")

def remove_operator_from_ops(identifier, ops_file='ops.json'):
    """Removes an operator from the ops.json file by UUID or username."""
    try:
        with open(ops_file, 'r') as file:
            ops = json.load(file)
    except FileNotFoundError:
        print("No operators to remove.")
        return

    # Try to remove by UUID first
    ops = [op for op in ops if op['uuid'] != identifier]

    # If no operators were removed, try to fetch UUID by username and remove
    if len(ops) == len(json.load(open(ops_file))):
        try:
            user_uuid = fetch_uuid(identifier, True)
            print("uuid: ", user_uuid)
            ops = [op for op in ops if op['uuid'] != user_uuid]
        except Exception as e:
            print(e)
            return

    with open(ops_file, 'w') as file:
        json.dump(ops, file, indent=2)

    print(f"Removed operator with identifier {identifier} from {ops_file}")

def set_operator_permission(ops_file, identifier, new_level):
    """
    Sets the permission level of an operator by UUID or username.
    
    :param ops_file: Path to the ops.json file.
    :param identifier: UUID or username of the operator.
    :param new_level: New permission level to set.
    """
    try:
        with open(ops_file, 'r') as file:
            ops = json.load(file)
    except FileNotFoundError:
        print(f"File {ops_file} not found.")
        return
    
    # Find operator by UUID or username
    found = False
    for op in ops:
        if op['uuid'] == identifier or op['name'] == identifier:
            op['level'] = new_level
            found = True
            break
    
    if found:
        with open(ops_file, 'w') as file:
            json.dump(ops, file, indent=4)
        print(f"Updated {identifier}'s permission level to {new_level}.")
    else:
        print(f"No operator found with identifier {identifier}.")

def list_operators(ops_file='ops.json'):
    """Lists all operators in the ops.json file."""
    try:
        with open(ops_file, 'r') as file:
            ops = json.load(file)
    except FileNotFoundError:
        print("No operators found.")
        return

    for op in ops:
        print(f"{op['name']} ({op['uuid']}, {op['level']})")

def add_ip_ban(ip, source, reason, expires="forever", ip_bans_file='ip_bans.json'):
    """Adds a new IP ban to the ip_bans.json file."""
    try:
        with open(ip_bans_file, 'r') as file:
            ip_bans = json.load(file)
    except FileNotFoundError:
        ip_bans = []

    new_ban = {
        "ip": ip,
        "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": source,
        "expires": expires,
        "reason": reason
    }

    ip_bans.append(new_ban)

    with open(ip_bans_file, 'w') as file:
        json.dump(ip_bans, file, indent=2)

    print(f"Added IP ban for {ip} to {ip_bans_file}")

def add_ban(uuid, name, source, reason, expires="forever", bans_file='bans.json'):
    """Adds a new ban to the bans.json file."""
    try:
        with open(bans_file, 'r') as file:
            bans = json.load(file)
    except FileNotFoundError:
        bans = []

    new_ban = {
        "uuid": uuid,
        "name": name,
        "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": source,
        "expires": expires,
        "reason": reason
    }

    bans.append(new_ban)

    with open(bans_file, 'w') as file:
        json.dump(bans, file, indent=2)

    print(f"Added ban for {name} ({uuid}) to {bans_file}")

def add_whitelist_entry(uuid, name, whitelist_file='whitelist.json'):
    """Adds a new entry to the whitelist.json file."""
    try:
        with open(whitelist_file, 'r') as file:
            whitelist = json.load(file)
    except FileNotFoundError:
        whitelist = []

    new_entry = {
        "uuid": uuid,
        "name": name
    }

    whitelist.append(new_entry)

    with open(whitelist_file, 'w') as file:
        json.dump(whitelist, file, indent=2)

    print(f"Added whitelist entry for {name} ({uuid}) to {whitelist_file}")

def remove_ip_ban(ip, ip_bans_file='ip_bans.json'):
    """Removes an IP ban from the ip_bans.json file."""
    try:
        with open(ip_bans_file, 'r') as file:
            ip_bans = json.load(file)
    except FileNotFoundError:
        print("No IP bans to remove.")
        return

    ip_bans = [ban for ban in ip_bans if ban['ip'] != ip]

    with open(ip_bans_file, 'w') as file:
        json.dump(ip_bans, file, indent=2)

    print(f"Removed IP ban for {ip} from {ip_bans_file}")

def remove_ban(identifier, bans_file='bans.json'):
    """Removes a ban from the bans.json file by UUID."""
    try:
        with open(bans_file, 'r') as file:
            bans = json.load(file)
    except FileNotFoundError:
        print("No bans to remove.")
        return

    # Try to remove by UUID first
    removed_by_uuid = False
    bans = [ban for ban in bans if ban['uuid'] != identifier]
    if len(bans) != len(json.load(open(bans_file))):
        removed_by_uuid = True

    # If nothing was removed by UUID, try to fetch UUID from username
    if not removed_by_uuid:
        try:
            uuid = fetch_uuid(identifier, True)
            bans = [ban for ban in bans if ban['uuid'] != uuid]
        except Exception as e:
            print(f"Error fetching UUID for {identifier}: {e}")
            return

    with open(bans_file, 'w') as file:
        json.dump(bans, file, indent=2)

    print(f"Removed ban for {identifier} from {bans_file}")

def remove_whitelist_entry(identifier, whitelist_file='whitelist.json'):
    """Removes an entry from the whitelist.json file by UUID."""
    try:
        with open(whitelist_file, 'r') as file:
            whitelist = json.load(file)
    except FileNotFoundError:
        print("No whitelist entries to remove.")
        return

    # Try to remove by UUID first
    removed_by_uuid = False
    whitelist = [entry for entry in whitelist if entry['uuid'] != identifier]
    if len(whitelist) == len(json.load(open(whitelist_file))):
        removed_by_uuid = True

    # If nothing was removed by UUID, try to fetch UUID from username
    if not removed_by_uuid:
        try:
            uuid = fetch_uuid(identifier, True)
            whitelist = [entry for entry in whitelist if entry['uuid'] != uuid]
        except Exception as e:
            print(f"Error fetching UUID for {identifier}: {e}")
            return

    with open(whitelist_file, 'w') as file:
        json.dump(whitelist, file, indent=2)

    print(f"Removed whitelist entry for {identifier} from {whitelist_file}")


def list_ip_bans(ip_bans_file='ip_bans.json'):
    """Lists all IP bans in the ip_bans.json file."""
    try:
        with open(ip_bans_file, 'r') as file:
            ip_bans = json.load(file)
    except FileNotFoundError:
        print("No IP bans found.")
        return

    for ban in ip_bans:
        expires = ban['expires'] if ban['expires'] != 'forever' else 'forever'
        print(f"IP: {ban['ip']}, Created: {ban['created']}, Source: {ban['source']}, Expires: {expires}, Reason: {ban['reason']}")

def list_bans(bans_file='bans.json'):
    """Lists all bans in the bans.json file."""
    try:
        with open(bans_file, 'r') as file:
            bans = json.load(file)
    except FileNotFoundError:
        print("No bans found.")
        return

    for ban in bans:
        expires = ban['expires'] if ban['expires'] != 'forever' else 'forever'
        print(f"UUID: {ban['uuid']}, Name: {ban['name']}, Created: {ban['created']}, Source: {ban['source']}, Expires: {expires}, Reason: {ban['reason']}")

def list_whitelist(whitelist_file='whitelist.json'):
    """Lists all whitelist entries in the whitelist.json file."""
    try:
        with open(whitelist_file, 'r') as file:
            whitelist = json.load(file)
    except FileNotFoundError:
        print("No whitelist entries found.")
        return

    for entry in whitelist:
        print(f"UUID: {entry['uuid']}, Name: {entry['name']}")

def extract_zip(zip_file, extract_folder):
    """
    Extracts the contents of a zip file into a specified folder.

    Parameters:
    - zip_file (str): Path to the zip file to be extracted.
    - extract_folder (str): Path to the folder where the contents should be extracted.
    """
    try:
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            zip_ref.extractall(extract_folder)
        print(f"Successfully extracted '{zip_file}' into '{extract_folder}'.")
    except zipfile.BadZipFile as e:
        print(f"Error: '{zip_file}' is not a valid zip file.")
    except zipfile.LargeZipFile as e:
        print(f"Error: '{zip_file}' is too large to handle.")
    except zipfile.ZipError as e:
        print(f"Error: Failed to extract '{zip_file}'. {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def create_backup(instance_name, backup_name):
    """
    Creates a backup of a Minecraft server instance.
    
    Args:
    - instance_name (str): Name of the Minecraft server instance.
    - backup_name (str): Name for the backup.
    
    Returns:
    - bool: True if backup creation was successful, False otherwise.
    """
    try:
        instance_path = os.path.join("instances", "server", instance_name)
        if not os.path.exists(instance_path):
            print(f"Instance '{instance_name}' does not exist.")
            return False
        
        backup_dir = os.path.join("instances", "backups", instance_name)
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)
        
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        backup_name_with_time = f"{backup_name}_{timestamp}"
        backup_path = os.path.join(backup_dir, backup_name_with_time)
        
        shutil.copytree(instance_path, backup_path)
        print(f"Backup '{backup_name_with_time}' created for instance '{instance_name}'.")
        return True
    except Exception as e:
        print(f"Failed to create backup for instance '{instance_name}': {e}")
        return False

def load_backup(instance_name, backup_name):
    """
    Loads a backup of a Minecraft server instance.
    
    Args:
    - instance_name (str): Name of the Minecraft server instance.
    - backup_name (str): Name of the backup to load.
    
    Returns:
    - bool: True if backup loading was successful, False otherwise.
    """
    try:
        backup_dir = os.path.join("instances", "backups", instance_name)
        backup_path = os.path.join(backup_dir, backup_name)
        
        if not os.path.exists(backup_path):
            print(f"Backup '{backup_name}' for instance '{instance_name}' does not exist.")
            return False
        
        instance_path = os.path.join("instances", "server", instance_name)
        if os.path.exists(instance_path):
            shutil.rmtree(instance_path)
        
        shutil.copytree(backup_path, instance_path)
        print(f"Backup '{backup_name}' loaded successfully for instance '{instance_name}'.")
        return True
    except Exception as e:
        print(f"Failed to load backup '{backup_name}' for instance '{instance_name}': {e}")
        return False

def delete_backup(instance_name, backup_name):
    """
    Deletes a backup of a Minecraft server instance.
    
    Args:
    - instance_name (str): Name of the Minecraft server instance.
    - backup_name (str): Name of the backup to delete.
    
    Returns:
    - bool: True if backup deletion was successful, False otherwise.
    """
    try:
        backup_dir = os.path.join("instances", "backups", instance_name)
        backup_path = os.path.join(backup_dir, backup_name)
        
        if not os.path.exists(backup_path):
            print(f"Backup '{backup_name}' for instance '{instance_name}' does not exist.")
            return False
        
        shutil.rmtree(backup_path)
        print(f"Backup '{backup_name}' deleted successfully for instance '{instance_name}'.")
        return True
    except Exception as e:
        print(f"Failed to delete backup '{backup_name}' for instance '{instance_name}': {e}")
        return False

def list_backups(instance_name):
    """
    Lists all backups of a Minecraft server instance.
    
    Args:
    - instance_name (str): Name of the Minecraft server instance.
    
    Returns:
    - list: List of backup names (strings).
    """
    try:
        backup_dir = os.path.join("instances", "backups", instance_name)
        if not os.path.exists(backup_dir):
            print(f"No backups found for instance '{instance_name}'.")
            return []
        
        backups = os.listdir(backup_dir)
        if not backups:
            print(f"No backups found for instance '{instance_name}'.")
            return []
        
        print(f"Backups for instance '{instance_name}':")
        for backup in backups:
            print(backup)
        
        return backups
    except Exception as e:
        print(f"Failed to list backups for instance '{instance_name}': {e}")
        return []

def generate_resourcepack_sha1(filepath):
    sha1 = hashlib.sha1()
    with open(filepath, 'rb') as f:
        while True:
            data = f.read(65536)  # Read in 64k chunks
            if not data:
                break
            sha1.update(data)
    return sha1.hexdigest()

def export_instance(source_folder):
    file_path = eg.filesavebox(msg="Save Instance as .zip",
                               title="Save as .zip File",
                               default="instance.zip",
                               filetypes=["*.zip"])

    if file_path:
        try:
            with zipfile.ZipFile(file_path, 'w') as zipf:
                for root, dirs, files in os.walk(source_folder):
                    for file in files:
                        file_path2 = os.path.join(root, file)
                        zipf.write(file_path, os.path.relpath(file_path2, source_folder))

            print(f"Instance exported successfully as {file_path}")
        except Exception as e:
            print(f"Error exporting instance: {str(e)}")

def import_instance(destination_folder):
    import_path = eg.fileopenbox(title="Select .zip File to Import",
                                 filetypes=["*.zip"])
    
    if import_path:
        try:
            with zipfile.ZipFile(import_path, 'r') as zip_ref:
                zip_ref.extractall(destination_folder)
            
            print(f"Instance imported successfully to {destination_folder}")
        except Exception as e:
            print(f"Error importing instance: {str(e)}")

def delete_directory(directory_path):
    if os.path.exists(directory_path) and os.path.isdir(directory_path):
        try:
            shutil.rmtree(directory_path)
        except Exception as e:
            print(f"Error deleting directory '{directory_path}': {str(e)}")

def main():
    """Main program loop"""
    global selected_instance

    while True:
        try:
            input("Press enter to continue")
            print("\nWhat would you like to do?")

            if selected_instance is None:
                print("1. Create a new Minecraft server instance")
                print("2. List all Minecraft server instances")
                print("3. Select a Minecraft server instance")
                print("4. Import a instance")
                print("0. Exit")
                choice = input("Enter your choice: ")

                if choice == "1":
                    name = input("Enter instance name: ")
                    version = input("Enter Minecraft version: ")
                    create_instance(name, version, SERVER_DIR)
                elif choice == "2":
                    list_instances(SERVER_DIR)
                elif choice == "3":
                    name = input("Enter instance name to select: ")
                    if os.path.exists(os.path.join(SERVER_DIR, name)):
                        if name != "":
                         selected_instance = name
                        else:
                         print("You must provide an instance name.")
                    else:
                        print(f"Instance '{name}' does not exist.")
                elif choice == "4":
                    name = input("Enter name of how to save imported instance")
                    if not os.path.exists(os.path.join(SERVER_DIR, name)):
                     import_instance(os.path.join(SERVER_DIR, name))
                    else:
                     print("Instance name in use")
                elif choice == "0":
                    print("Exiting...")
                    break
                else:
                    print("Invalid choice. Please try again.")
            else:
                print(f"Selected Instance: {selected_instance}")
                print("Categories:")
                print("1. General")
                print("2. World")
                print("3. Datapacks")
                print("4. Optimization")
                print("5. Branding")
                print("6. Resourcepacks")
                print("7. Administrator Management")
                print("8. Plugins (Plugin software only)")
                print("9. Mods (Mod software only)")
                print("10. Gamemode")
                print("11. Spawning")
                print("12. Ban, IP Ban, Whitelist Management")
                print("13. Backups")
                print("14. Ingame Systematics")
                print("15. Files")
                print("16. Crash reports")
                print("17. Logs")
                print("0. Back to selection")

                category = input("Enter your choice: ")

                if category == "1":
                    while True:
                        print("General:")
                        print("1. Delete this server")
                        print("2. Launch this server")
                        print("3. Reinstall this server (Make sure to create a backup before. does not necesarily mean all data is lost.)")
                        print("4. Export this server")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            delete_instance(selected_instance, SERVER_DIR)
                            selected_instance = None
                            break
                        elif choice == "2":
                            port = input("Enter port number: ")
                            launch_instance(selected_instance, SERVER_DIR, port)
                        elif choice == "3":
                            version = input("Enter New Minecraft version: ")
                            change_version(selected_instance, version, SERVER_DIR)
                        elif choice == "4":
                             export_instance(os.path.join(SERVER_DIR, selected_instance))
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")
                
                elif category == "2":
                    while True:
                        print("World:")
                        print("1. Set the world save")
                        print("2. Delete the world save")
                        print("3. Set max world size")
                        print("4. Toggle nether")
                        print("5. Set build height")
                        print("6. Toggle structure generation")
                        print("7. Set seed for world generator")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            add_world_to_instance(selected_instance, SERVER_DIR)
                        elif choice == "2":
                            delete_world(selected_instance, SERVER_DIR)
                        elif choice == "3":
                            maxsize = input("Enter max world size: ")
                            try:
                                maxsize = int(maxsize)
                                set_max_world_size(os.path.join(SERVER_DIR, selected_instance, "server.properties"), maxsize)
                            except ValueError:
                                print("Error: Please enter a valid integer for max world size.")
                        elif choice == "4":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["allow-nether"] == "true":
                                properties["allow-nether"] = "false"
                                print("Disabled Nether!")
                            elif properties["allow-nether"] == "false":
                                properties["allow-nether"] = "true"
                                print("Enabled Nether!")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "5":
                            buildheight = input("Enter build height: ")
                            try:
                                buildheight = int(buildheight)
                                set_max_buildheight(os.path.join(SERVER_DIR, selected_instance, "server.properties"), buildheight)
                            except ValueError:
                                print("Error: Please enter a valid integer for max build height.")
                        elif choice == "6":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["generate-structures"] == "true":
                                properties["generate-structures"] = "false"
                                print("Disabled Structure Generation!")
                            elif properties["generate-structures"] == "false":
                                properties["generate-structures"] = "true"
                                print("Enabled Structure Generation!")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "7":
                            seed = input("Enter world generator seed (empty for random): ")
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            properties["level-seed"] = seed
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")
                
                elif category == "3":
                    while True:
                        print("Datapacks:")
                        print("1. Add a data pack")
                        print("2. Delete a data pack")
                        print("3. List all data packs")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            add_data_pack_to_instance(selected_instance, SERVER_DIR)
                        elif choice == "2":
                            delete_data_pack_from_instance(selected_instance, SERVER_DIR)
                        elif choice == "3":
                            list_data_packs(selected_instance, SERVER_DIR)
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "4":
                    while True:
                        print("Optimization:")
                        print("1. Set max players")
                        print("2. Set network compression threshold")
                        print("3. Set player idle timeout")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            maxplayers = input("Enter max players: ")
                            try:
                                maxplayers = int(maxplayers)
                                set_max_players(os.path.join(SERVER_DIR, selected_instance, "server.properties"), maxplayers)
                            except ValueError:
                                print("Error: Please enter a valid integer for max players.")
                        elif choice == "2":
                            nwcomptreshold = input("Enter network compression threshold: ")
                            try:
                                nwcomptreshold = int(nwcomptreshold)
                                set_network_compression_threshold(os.path.join(SERVER_DIR, selected_instance, "server.properties"), nwcomptreshold)
                            except ValueError:
                                print("Error: Please enter a valid integer for network compression threshold.")
                        elif choice == "3":
                            idletimeout = input("Enter player idle timeout (in minutes. 0 to disable.): ")
                            try:
                                idletimeout = int(idletimeout)
                                set_player_idle_timeout(os.path.join(SERVER_DIR, selected_instance, "server.properties"), idletimeout)
                            except ValueError:
                                print("Error: Please enter a valid integer for player idle timeout.")
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "5":
                    while True:
                        print("Branding:")
                        print("1. Set motd (encode before entering)")
                        print("2. Set server icon")
                        print("3. Remove server icon")
                        print("4. Toggle Status Display")
                        print("5. Toggle Online player hider")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            motd = input("Enter motd (color codes allowed): ")
                            set_motd(os.path.join(SERVER_DIR, selected_instance, "server.properties"), motd)
                        elif choice == "2":
                            set_server_icon(os.path.join(SERVER_DIR, selected_instance))
                        elif choice == "3":
                            os.unlink(os.path.join(SERVER_DIR, selected_instance, "server-icon.png"))
                        elif choice == "4":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["enable-status"] == "true":
                                properties["enable-status"] = "false"
                                print("No longer showing server status.")
                            elif properties["enable-status"] == "false":
                                properties["enable-status"] = "true"
                                print("Now showing server status.")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "5":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["hide-online-players"] == "true":
                                properties["hide-online-players"] = "false"
                                print("No longer hiding online players.")
                            elif properties["hide-online-players"] == "false":
                                properties["hide-online-players"] = "true"
                                print("Now hiding online players.")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "6":
                    while True:
                        print("Resourcepacks:")
                        print("1. Set server resourcepack")
                        print("2. Remove server resourcepack")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            set_server_resourcepack(os.path.join(SERVER_DIR, selected_instance))
                        elif choice == "2":
                            remove_server_resourcepack(os.path.join(SERVER_DIR, selected_instance))
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "7":
                    while True:
                        print("Administrator Management:")
                        print("1. Add Operator")
                        print("2. Remove Operator")
                        print("3. List Operators")
                        print("4. Set Operator Permission Level")
                        print("5. Set Default Operator Permission Level")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            user = input("Enter username of user to add as operator: ")
                            permlevel = input("Enter permission level of the operator (1-4): ")
                            try:
                                permlevel = int(permlevel)
                                add_operator_to_ops(user, permlevel, os.path.join(SERVER_DIR, selected_instance, "ops.json"))
                            except ValueError:
                                print("Error: Please enter a valid integer for permission level.")
                        elif choice == "2":
                            user = input("Enter username or UUID of user to remove operator: ")
                            remove_operator_from_ops(user, os.path.join(SERVER_DIR, selected_instance, "ops.json"))
                        elif choice == "3":
                            list_operators(os.path.join(SERVER_DIR, selected_instance, "ops.json"))
                        elif choice == "4":
                            user = input("Enter username or UUID of user to set permission level: ")
                            permlevel = input("Enter new permission level (1-4): ")
                            try:
                                permlevel = int(permlevel)
                                set_operator_permission(os.path.join(SERVER_DIR, selected_instance, "ops.json"), user, permlevel)
                            except ValueError:
                                print("Error: Please enter a valid integer for permission level.")
                        elif choice == "5":
                            defaultoppermlevel = input("Enter default operator permission level: ")
                            try:
                                defaultoppermlevel = int(defaultoppermlevel)
                                set_default_operator_permission_level(os.path.join(SERVER_DIR, selected_instance, "server.properties"), defaultoppermlevel)
                            except ValueError:
                                print("Error: Please enter a valid integer for operator default permission level.")
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "8":
                    while True:
                        print("Plugins:")
                        print("1. Add a plugin")
                        print("2. Delete a plugin")
                        print("3. List all plugins")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            add_plugin_to_instance(selected_instance, SERVER_DIR)
                        elif choice == "2":
                            delete_plugin_from_instance(selected_instance, SERVER_DIR)
                        elif choice == "3":
                            list_plugins(selected_instance, SERVER_DIR)
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "9":
                    while True:
                        print("Mods:")
                        print("1. Add a mod")
                        print("2. Delete a mod")
                        print("3. List all mods")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            add_mod_to_instance(selected_instance, SERVER_DIR)
                        elif choice == "2":
                            delete_mod_from_instance(selected_instance, SERVER_DIR)
                        elif choice == "3":
                            list_mod(selected_instance, SERVER_DIR)
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "10":
                    while True:
                        print("Gamemode:")
                        print("1. Set default gamemode")
                        print("2. Toggle Force Default Gamemode")
                        print("3. Toggle hardcore mode")
                        print("4. Toggle PVP")
                        print("5. Toggle Allow Flight")
                        print("6. Toggle Online Mode")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            defaultgamemode = input("Enter default gamemode (0 for survival, 1 for creative, 2 for adventure): ")
                            try:
                                defaultgamemode = int(defaultgamemode)
                                set_default_gamemode(os.path.join(SERVER_DIR, selected_instance, "server.properties"), defaultgamemode)
                            except ValueError:
                                print("Error: Please enter a valid integer for default gamemode.")
                        elif choice == "2":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["force-gamemode"] == "true":
                                properties["force-gamemode"] = "false"
                                print("No longer forcing default gamemode.")
                            elif properties["force-gamemode"] == "false":
                                properties["force-gamemode"] = "true"
                                print("Now forcing default gamemode")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "3":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["hardcore"] == "true":
                                properties["hardcore"] = "false"
                                print("Disabled Hardcore!")
                            elif properties["hardcore"] == "false":
                                properties["hardcore"] = "true"
                                print("Enabled Hardcore!")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "4":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["pvp"] == "true":
                                properties["pvp"] = "false"
                                print("Disabled PVP!")
                            elif properties["pvp"] == "false":
                                properties["pvp"] = "true"
                                print("Enabled PVP!")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "5":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["allow-flight"] == "true":
                                properties["allow-flight"] = "false"
                                print("Disabled Allow Flight!")
                            elif properties["allow-flight"] == "false":
                                properties["allow-flight"] = "true"
                                print("Enabled Allow Flight!")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "6":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["online-mode"] == "true":
                                properties["online-mode"] = "false"
                                print("Disabled Online Mode! now this server is cracked.")
                            elif properties["online-mode"] == "false":
                                properties["online-mode"] = "true"
                                print("Enabled Online Mode! this server is no longer cracked.")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "11":
                    while True:
                        print("Spawning:")
                        print("1. Toggle Animal Spawning")
                        print("2. Toggle Monster Spawning")
                        print("3. Toggle NPC Spawning")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["spawn-animals"] == "true":
                                properties["spawn-animals"] = "false"
                                print("No longer spawning animals.")
                            elif properties["spawn-animals"] == "false":
                                properties["spawn-animals"] = "true"
                                print("Now spawning animals.")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "2":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["spawn-monsters"] == "true":
                                properties["spawn-monsters"] = "false"
                                print("No longer spawning monsters.")
                            elif properties["spawn-monsters"] == "false":
                                properties["spawn-monsters"] = "true"
                                print("Now spawning monsters.")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "3":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["spawn-npcs"] == "true":
                                properties["spawn-npcs"] = "false"
                                print("No longer spawning npcs.")
                            elif properties["spawn-npcs"] == "false":
                                properties["spawn-npcs"] = "true"
                                print("Now spawning npcs.")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "12":
                    while True:
                        print("Ban, IP Ban, Whitelist Management")
                        print("1. Ban Management")
                        print("2. IP Ban Management")
                        print("3. Whitelist Management")
                        print("0. Back to main menu")

                        category_choice = input("Enter your choice: ")

                        if category_choice == "1":
                            while True:
                                print("Ban Management:")
                                print("1. Add a ban")
                                print("2. Remove a ban")
                                print("3. List all bans")
                                print("0. Back")

                                ban_choice = input("Enter your choice: ")

                                if ban_choice == "1":
                                    name = input("Enter player name to ban: ")
                                    reason = input("Enter ban reason: ")
                                    expires = input("Enter expiration (empty or 'forever' for indefinite): ")
                                    uuid = fetch_uuid(name, True)
                                    if uuid:
                                        add_ban(uuid, name, "SYS_SuperDiamondMC_Management", reason, expires, os.path.join(SERVER_DIR, selected_instance, "banned-players.json"))
                                    else:
                                        print(f"Unable to fetch UUID for '{name}'.")
                                elif ban_choice == "2":
                                    identifier = input("Enter UUID or username to remove from bans: ")
                                    remove_ban(identifier, os.path.join(SERVER_DIR, selected_instance, "banned-players.json"))
                                elif ban_choice == "3":
                                    list_bans(os.path.join(SERVER_DIR, selected_instance, "banned-players.json"))
                                elif ban_choice == "0":
                                    break
                                else:
                                    print("Invalid choice. Please try again.")

                        elif category_choice == "2":
                            while True:
                                print("IP Ban Management:")
                                print("1. Add an IP ban")
                                print("2. Remove an IP ban")
                                print("3. List all IP bans")
                                print("0. Back")

                                ip_ban_choice = input("Enter your choice: ")

                                if ip_ban_choice == "1":
                                    ip = input("Enter IP to ban: ")
                                    reason = input("Enter ban reason: ")
                                    expires = input("Enter expiration (empty or 'forever' for indefinite): ")
                                    add_ip_ban(ip, "SYS_SuperDiamondMC_Management", reason, expires, os.path.join(SERVER_DIR, selected_instance, "banned-ips.json"))
                                elif ip_ban_choice == "2":
                                    ip = input("Enter IP to remove from IP bans: ")
                                    remove_ip_ban(ip, os.path.join(SERVER_DIR, selected_instance, "banned-ips.json"))
                                elif ip_ban_choice == "3":
                                    list_ip_bans(os.path.join(SERVER_DIR, selected_instance, "banned-ips.json"))
                                elif ip_ban_choice == "0":
                                    break
                                else:
                                    print("Invalid choice. Please try again.")

                        elif category_choice == "3":
                            while True:
                                print("Whitelist Management:")
                                print("1. Add a player to whitelist")
                                print("2. Remove a player from whitelist")
                                print("3. List all whitelist entries")
                                print("0. Back")

                                whitelist_choice = input("Enter your choice: ")

                                if whitelist_choice == "1":
                                    name = input("Enter player name to whitelist: ")
                                    uuid = fetch_uuid(name, True)
                                    if uuid:
                                        add_whitelist_entry(uuid, name, os.path.join(SERVER_DIR, selected_instance, "whitelist.json"))
                                    else:
                                        print(f"Unable to fetch UUID for '{name}'.")
                                elif whitelist_choice == "2":
                                    identifier = input("Enter UUID or username to remove from whitelist: ")
                                    remove_whitelist_entry(identifier, os.path.join(SERVER_DIR, selected_instance, "whitelist.json"))
                                elif whitelist_choice == "3":
                                    list_whitelist(os.path.join(SERVER_DIR, selected_instance, "whitelist.json"))
                                elif whitelist_choice == "4":
                                    properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                                    if properties["white-list"] == "true":
                                        properties["white-list"] = "false"
                                        print("Now ignoring whitelist.")
                                    elif properties["white-list"] == "false":
                                        properties["white-list"] = "true"
                                        print("Now using whitelist.")
                                    write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                                elif whitelist_choice == "0":
                                    break
                                else:
                                    print("Invalid choice. Please try again.")

                        elif category_choice == "0":
                            print("Returning to main menu...")
                            break

                        else:
                            print("Invalid choice. Please try again.")

                elif category == "13":
                    while True:
                        print("Backups:")
                        print("1. Create backup")
                        print("2. List backups")
                        print("3. Load Backup")
                        print("4. Delete backup")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            name = input("Enter new backup name: ")
                            create_backup(selected_instance, name)
                        elif choice == "2":
                            list_backups(selected_instance)
                        elif choice == "3":
                            name = input("Enter backup name to load: ")
                            load_backup(selected_instance, name)
                        elif choice == "4":
                            name = input("Enter backup name to delete: ")
                            delete_backup(selected_instance, name)
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "14":
                    while True:
                        print("Ingame Systematics:")
                        print("1. Toggle Command Blocks")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            properties = read_properties(os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                            if properties["enable-command-block"] == "true":
                                properties["enable-command-block"] = "false"
                                print("Disabled Command Blocks.")
                            elif properties["enable-command-block"] == "false":
                                properties["enable-command-block"] = "true"
                                print("Enabled Command Blocks.")
                            write_properties(properties, os.path.join(SERVER_DIR, selected_instance, "server.properties"))
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")

                elif category == "15":
                    while True:
                        print("Files:")
                        print("1. Open Server Folder")
                        print("0. Back to categories")
                        choice = input("Enter your choice: ")

                        if choice == "1":
                            os.startfile(os.path.join(SERVER_DIR, selected_instance))
                        elif choice == "0":
                            break
                        else:
                            print("Invalid choice. Please try again.")
                
                elif category == "16":
                    crash_report_manager(os.path.join(SERVER_DIR, selected_instance))

                elif category == "17":
                    log_manager(os.path.join(SERVER_DIR, selected_instance))
                    
                elif category == "0":
                    selected_instance = None
                else:
                    print("Invalid choice. Please try again.")

        except Exception as e:
            print("Error:", e)

print("Loaded! starting application.")
if __name__ == "__main__":
    main()
